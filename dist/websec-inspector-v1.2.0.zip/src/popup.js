let lastReport = null;
let analysisRun = 0;
const $ = id => document.getElementById(id);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));

function renderFinding(f){const row=document.createElement("article");row.className=`check ${f.status}`;row.innerHTML=`<div>${{pass:"✓",warn:"⚠",fail:"✕",info:"•",unknown:"?"}[f.status]}</div><div><div class="name">${esc(f.name)}</div><div class="desc">${esc(f.summary)}</div><div class="recommendation"><b>Recomendación:</b> ${esc(f.recommendation)}</div>${f.evidence?`<div class="evidence" title="${esc(f.evidence)}">Valor: ${esc(f.evidence.slice(0,150))}</div>`:""}</div><div class="penalty">${f.penalty?`−${f.penalty}`:""}</div>`;$("checks").appendChild(row)}
function download(content,type,name){const url=URL.createObjectURL(new Blob([content],{type}));const a=document.createElement("a");a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}
function abuseRisk(score){if(score>=80)return{label:"CRÍTICO",cls:"high"};if(score>=50)return{label:"ALTO",cls:"high"};if(score>=20)return{label:"MEDIO",cls:"medium"};return{label:"BAJO",cls:"low"}}
function combinedScore(localScore,threat){if(!threat?.configured||threat?.error||typeof threat.abuseConfidenceScore!=="number")return localScore;return Math.max(0,localScore-Math.round(Math.min(100,Math.max(0,threat.abuseConfidenceScore))*.20))}
function renderThreat(threat){const badge=$("abuseStatus"),box=$("abuseResult");if(!threat?.configured){badge.className="mini-badge neutral";badge.textContent="SIN CONFIGURAR";box.textContent="Añade tu API Key para activar la comprobación de reputación.";return}if(threat.error){badge.className="mini-badge high";badge.textContent=threat.status===429?"CUOTA":"ERROR";box.textContent=threat.status===429?"AbuseIPDB ha rechazado la consulta por límite de peticiones. Inténtalo más tarde.":`No se pudo consultar AbuseIPDB: ${threat.error}`;return}const risk=abuseRisk(threat.abuseConfidenceScore);badge.className=`mini-badge ${risk.cls}`;badge.textContent=risk.label;box.innerHTML=`<div class="threat-grid"><div><span>IP analizada</span><b>${esc(threat.ipAddress)}</b></div><div><span>Abuse Confidence</span><b>${esc(threat.abuseConfidenceScore)}%</b></div><div><span>Reports · 90 días</span><b>${esc(threat.totalReports)}</b></div><div><span>País</span><b>${esc(threat.countryCode||"—")}</b></div><div><span>ISP</span><b>${esc(threat.isp||"—")}</b></div><div><span>Tipo de uso</span><b>${esc(threat.usageType||"—")}</b></div></div><div class="threat-note">${threat.cached?"Resultado reutilizado desde caché local · ":""}Una IP compartida o CDN puede tener reputación ajena al sitio; AbuseIPDB puede restar hasta 20 puntos; la ausencia de reportes no aumenta la puntuación.</div>`}
function renderScore(data){$("score").textContent=`${data.score}/100`;$("barFill").style.width=`${data.score}%`;const badge=$("riskBadge");badge.className="badge "+(data.score>=85?"low":data.score>=60?"medium":"high");badge.textContent=data.score>=85?"BAJO":data.score>=60?"MEDIO":"ALTO";$("summary").textContent=data.score>=85?"Buena configuración básica en las señales observadas.":data.score>=60?"Hay recomendaciones que conviene revisar.":"Se detectaron riesgos o configuraciones débiles.";$("breakdown").innerHTML=`Score local: <b>${data.localScore}/100</b><br>Penalización local: −${data.totalPenalty}<br>${data.threatIntel?.abuseIpDb?.configured&&!data.threatIntel.abuseIpDb.error?`Reputación AbuseIPDB: <b>${100-data.threatIntel.abuseIpDb.abuseConfidenceScore}/100</b> (penalización máxima: 20 puntos)<br>`:""}<b>Resultado global: ${data.score}/100</b>`}

function buildHtmlReport(report){
  const contextSection='<section><h2>Cobertura y alcance</h2><p>'+esc(report.coverage?.complete?"Fuentes comprobadas: cabeceras, página y cookies.":"ANÁLISIS PARCIAL: faltan fuentes de información. La puntuación no es un veredicto de seguridad.")+'</p><h2>Acciones prioritarias</h2><ol>'+report.findings.filter(f=>f.status==="fail"||f.status==="warn").sort((a,b)=>b.penalty-a.penalty).slice(0,3).map(f=>'<li>'+esc(f.name)+': '+esc(f.recommendation)+'</li>').join("")+'</ol><h2>Comparación local</h2><p>'+esc(report.comparison?.message||"Sin comparación guardada.")+'</p><ul>'+(report.comparison?.changes||[]).map(t=>'<li>'+esc(t)+'</li>').join("")+'</ul></section>';
  const findings=Array.isArray(report.findings)?report.findings:[];
  const counts=report.counts||{};
  const statusLabels={unknown:"No comprobado",pass:"Correcto",warn:"Revisar",fail:"Riesgo",info:"Informativo"};
  const rows=findings.map(f=>`<tr><td><span class="status ${esc(f.status||"info")}">${esc(statusLabels[f.status]||f.status||"—")}</span></td><td><strong>${esc(f.name||"—")}</strong></td><td>${esc(f.summary||"—")}</td><td>${esc(f.recommendation||"—")}</td><td class="evidence">${esc(f.evidence||"—")}</td><td class="number">${Number(f.penalty)||0}</td></tr>`).join("");
  const threat=report.threatIntel?.abuseIpDb;
  const threatSection=threat?.configured&&!threat.error?`<section><h2>Threat Intelligence · AbuseIPDB</h2><div class="grid"><div><span>IP</span><strong>${esc(threat.ipAddress||"—")}</strong></div><div><span>Abuse Confidence Score</span><strong>${esc(threat.abuseConfidenceScore??"—")}%</strong></div><div><span>Reportes</span><strong>${esc(threat.totalReports??"—")}</strong></div><div><span>País</span><strong>${esc(threat.countryCode||"—")}</strong></div><div><span>ISP</span><strong>${esc(threat.isp||"—")}</strong></div><div><span>Tipo de uso</span><strong>${esc(threat.usageType||"—")}</strong></div><div><span>Origen del resultado</span><strong>${threat.cached?"Caché local":"Consulta directa"}</strong></div></div><p class="note">La reputación de una IP compartida, CDN o proveedor cloud es una señal contextual y no demuestra por sí sola que el sitio sea malicioso.</p></section>`:"";
  const date=report.analyzedAt?new Date(report.analyzedAt).toLocaleString("es-ES",{dateStyle:"long",timeStyle:"medium"}):"—";
  return `<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>WebSec Inspector · ${esc(report.hostname||"")}</title><style>
  :root{color-scheme:light;--ink:#172033;--muted:#64748b;--line:#dbe3ef;--panel:#f7f9fc;--brand:#2563eb;--pass:#15803d;--warn:#b45309;--fail:#b91c1c;--info:#475569}*{box-sizing:border-box}body{margin:0;background:#eef2f7;color:var(--ink);font:14px/1.5 system-ui,-apple-system,"Segoe UI",sans-serif}.page{max-width:1200px;margin:32px auto;background:white;box-shadow:0 12px 36px #1720331c}.header{padding:32px;background:linear-gradient(135deg,#111827,#1e3a8a);color:white}.brand{font-size:13px;letter-spacing:.12em;text-transform:uppercase;opacity:.78}.header h1{margin:5px 0 20px;font-size:30px}.meta{display:grid;grid-template-columns:1fr 1fr;gap:10px 28px}.meta span,.grid span{display:block;color:#cbd5e1;font-size:12px;text-transform:uppercase;letter-spacing:.05em}.meta strong{overflow-wrap:anywhere}main{padding:28px}section{margin-bottom:30px}h2{font-size:19px;margin:0 0 14px}.scores,.grid,.summary-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.score,.grid>div,.summary-grid>div{padding:18px;background:var(--panel);border:1px solid var(--line);border-radius:10px}.score strong{display:block;font-size:32px;color:var(--brand)}.score span,.summary-grid span,.grid span{color:var(--muted)}.summary-grid{grid-template-columns:repeat(4,minmax(0,1fr))}.summary-grid strong{display:block;font-size:24px}.table-wrap{overflow-x:auto;border:1px solid var(--line);border-radius:10px}table{width:100%;border-collapse:collapse;min-width:1050px}th,td{padding:12px;text-align:left;vertical-align:top;border-bottom:1px solid var(--line)}th{background:var(--panel);font-size:12px;text-transform:uppercase;color:var(--muted)}tr:last-child td{border-bottom:0}.status{display:inline-block;border-radius:999px;padding:3px 8px;color:white;font-size:12px;white-space:nowrap}.status.pass{background:var(--pass)}.status.warn{background:var(--warn)}.status.fail{background:var(--fail)}.status.info{background:var(--info)}.evidence{max-width:250px;overflow-wrap:anywhere}.number{text-align:right;font-weight:700}.note{color:var(--muted);font-size:13px}footer{padding:18px 28px;border-top:1px solid var(--line);color:var(--muted);font-size:12px}@media(max-width:700px){.page{margin:0}.meta,.scores,.grid{grid-template-columns:1fr}.summary-grid{grid-template-columns:repeat(2,1fr)}.header,main{padding:22px}}@media print{body{background:white}.page{margin:0;box-shadow:none}.table-wrap{overflow:visible}table{min-width:0;font-size:10px}.header{-webkit-print-color-adjust:exact;print-color-adjust:exact}}
  </style></head><body><div class="page"><header class="header"><div class="brand">WebSec Inspector / SecTF Labs</div><h1>Informe de seguridad web</h1><div class="meta"><div><span>Hostname</span><strong>${esc(report.hostname||"—")}</strong></div><div><span>Fecha del análisis</span><strong>${esc(date)}</strong></div><div><span>URL analizada</span><strong>${esc(report.url||"—")}</strong></div></div></header><main><section><h2>Puntuación</h2><div class="scores"><div class="score"><span>Security Score global</span><strong>${esc(report.score??"—")}/100</strong></div><div class="score"><span>Score local</span><strong>${esc(report.localScore??report.score??"—")}/100</strong></div></div></section><section><h2>Resumen de hallazgos</h2><div class="summary-grid"><div><span>Riesgos</span><strong>${esc(counts.fail??0)}</strong></div><div><span>Recomendaciones</span><strong>${esc(counts.warn??0)}</strong></div><div><span>Correctos</span><strong>${esc(counts.pass??0)}</strong></div><div><span>Informativos</span><strong>${esc(counts.info??0)}</strong></div></div><p class="note">Penalización local total: ${esc(report.totalPenalty??0)} puntos · ${findings.length} hallazgos analizados.</p></section><section><h2>Hallazgos</h2><div class="table-wrap"><table><thead><tr><th>Estado</th><th>Nombre</th><th>Resumen</th><th>Recomendación</th><th>Evidencia</th><th>Penalización</th></tr></thead><tbody>${rows||'<tr><td colspan="6">No hay hallazgos disponibles.</td></tr>'}</tbody></table></div></section>${contextSection}${threatSection}</main><footer>Generado por WebSec Inspector · SecTF Labs. El resultado es orientativo y no sustituye una auditoría de seguridad.</footer></div></body></html>`;
}


function renderContext(data) {
  $("coverage").textContent = data.coverage.complete ? "3/3 fuentes comprobadas: cabeceras, página y cookies. El alcance sigue limitado a las señales observadas." :
    data.coverage.checked+"/3 fuentes comprobadas. Resultado parcial: recarga la página y vuelve a analizar.";
  if (!data.coverage.complete) {
    $("riskBadge").textContent="PARCIAL"; $("riskBadge").className="badge neutral";
    $("summary").textContent="Puntuación provisional sobre las señales disponibles; faltan comprobaciones.";
  }
  const priorities=data.findings.filter(f=>f.status==="fail"||f.status==="warn")
    .sort((a,b)=>(b.status==="fail")-(a.status==="fail")||b.penalty-a.penalty).slice(0,3);
  $("priorities").innerHTML=priorities.length?priorities.map(f=>"<li><b>"+esc(f.name)+"</b>: "+esc(f.recommendation)+"</li>").join(""):"<li>No hay acciones prioritarias en las señales observadas.</li>";
  $("origins").innerHTML=data.thirdPartyOrigins.length?data.thirdPartyOrigins.map(o=>"<li>"+esc(o)+"</li>").join(""):"<li>Ninguno observado.</li>";
}
async function renderHistory(data, run) {
  try {
    const stored=await chrome.storage.local.get(WebSecHistory.KEY);
    if (run!==analysisRun) return;
    const records=Array.isArray(stored[WebSecHistory.KEY])?stored[WebSecHistory.KEY]:[];
    const current=WebSecHistory.snapshot(data);
    const previous=records.find(r=>r.origin===current.origin);
    data.comparison=WebSecHistory.compare(current,previous);
    $("comparison").textContent=data.comparison.message;
    $("changes").innerHTML=data.comparison.changes.map(t=>"<li>"+esc(t)+"</li>").join("");
  } catch { $("comparison").textContent="No se pudo leer el historial local."; }
}
async function analyze(forceThreat=false) {
  const run=++analysisRun;
  lastReport=null;
  $("saveHistory").disabled=true;
  $("exportJson").disabled=true; $("exportHtml").disabled=true;
  $("checks").innerHTML=""; $("priorities").innerHTML=""; $("origins").innerHTML="";
  $("comparison").textContent=""; $("changes").innerHTML=""; $("historyStatus").textContent="";
  $("coverage").textContent="Recopilando señales…"; $("counts").textContent=""; $("breakdown").textContent="";
  $("riskBadge").className="badge neutral"; $("riskBadge").textContent="—";
  $("host").textContent="Analizando…"; $("score").textContent="—"; $("barFill").style.width="0";
  $("abuseResult").textContent="Consultando configuración…";
  const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
  if(run!==analysisRun) return;
  if(!tab?.id||!/^https?:/i.test(tab.url||"")) {
    $("host").textContent="Página no compatible"; $("coverage").textContent="Abre una página HTTP o HTTPS.";
    $("summary").textContent="No hay análisis disponible."; renderThreat(null); return;
  }
  const u=new URL(tab.url);
  $("host").textContent=u.hostname;
  let page={},network={},cookies=[];
  const availability={headers:false,page:false,cookies:false};
  try { page=await chrome.tabs.sendMessage(tab.id,{type:"GET_PAGE_SIGNALS"}); availability.page=!!page && page.url===tab.url; } catch {}
  if(!availability.page) page={};
  try {
    network=await chrome.runtime.sendMessage({type:"GET_NETWORK_STATE",tabId:tab.id})||{};
    const networkUrl=new URL(network.url);
    const expected=new URL(tab.url); expected.hash=""; networkUrl.hash="";
    availability.headers=network.headersCaptured===true&&networkUrl.href===expected.href&&network.statusCode!==304;
  } catch {}
  try { cookies=await chrome.cookies.getAll({url:tab.url}); availability.cookies=true; } catch {}
  if(run!==analysisRun) return;
  const data={analyzedAt:new Date().toISOString(),url:tab.url,hostname:u.hostname,protocol:u.protocol,
    availability,headers:availability.headers?network.headers:{},statusCode:network.statusCode??null,
    redirects:network.redirects||0,thirdPartyOrigins:page.thirdPartyOrigins||[],
    hasPasswordField:!!page.hasPasswordField,forms:page.forms||[],
    cookies:cookies.map(c=>({name:c.name,domain:c.domain,secure:c.secure,httpOnly:c.httpOnly,
      sameSite:c.sameSite,session:c.session,firstParty:true}))};
  Object.assign(data,WebSecScoring.analyze(data));
  data.localScore=data.score; data.threatIntel={};
  $("redirects").textContent=availability.headers?data.redirects:"?";
  $("thirdParties").textContent=availability.page?data.thirdPartyOrigins.length:"?";
  $("cookiesCount").textContent=availability.cookies?data.cookies.length:"?";
  $("counts").textContent=data.counts.fail+" riesgos · "+data.counts.warn+" revisiones · "+data.counts.pass+" correctos · "+data.counts.unknown+" no comprobados";
  data.findings.forEach(renderFinding);
  renderScore(data); renderContext(data);
  let threat;
  try { threat=await chrome.runtime.sendMessage({type:"CHECK_ABUSEIPDB",hostname:u.hostname,force:forceThreat}); }
  catch { threat={configured:true,error:"No se pudo completar la consulta externa."}; }
  if(run!==analysisRun) return;
  data.threatIntel.abuseIpDb=threat; data.score=combinedScore(data.localScore,threat);
  renderThreat(threat); renderScore(data); renderContext(data);
  await renderHistory(data,run);
  if(run!==analysisRun) return;
  lastReport=data; $("saveHistory").disabled=false; $("exportJson").disabled=false; $("exportHtml").disabled=false;
}
async function saveHistory() {
  if(!lastReport) return;
  const report=lastReport;
  $("saveHistory").disabled=true;
  try {
    const snapshot=WebSecHistory.snapshot(report);
    const stored=await chrome.storage.local.get(WebSecHistory.KEY);
    const records=Array.isArray(stored[WebSecHistory.KEY])?stored[WebSecHistory.KEY]:[];
    await chrome.storage.local.set({[WebSecHistory.KEY]:[snapshot,...records].slice(0,50)});
    $("historyStatus").textContent="Análisis guardado en este navegador. Se comparará en el próximo análisis.";
  } catch { $("historyStatus").textContent="No se pudo guardar el historial."; }
  finally { $("saveHistory").disabled=!lastReport; }
}
async function clearHistory() {
  try {
    await chrome.storage.local.remove(WebSecHistory.KEY);
    $("comparison").textContent="Historial borrado."; $("changes").innerHTML="";
    if(lastReport) delete lastReport.comparison;
    $("historyStatus").textContent="Los análisis guardados se han eliminado.";
  } catch { $("historyStatus").textContent="No se pudo borrar el historial."; }
}
async function saveApiKey(){const key=$("apiKey").value.trim();if(!key){$("apiMessage").textContent="Introduce una API Key antes de guardar.";return}const result=await chrome.runtime.sendMessage({type:"SAVE_ABUSEIPDB_KEY",key});if(!result?.ok){$("apiMessage").textContent=`No se pudo guardar: ${result?.error||"error desconocido"}`;return}$("apiKey").value="";$("apiMessage").textContent="API Key guardada localmente. Reanalizando…";$("apiSettings").open=false;await analyze(true)}
async function removeApiKey(){const result=await chrome.runtime.sendMessage({type:"SAVE_ABUSEIPDB_KEY",key:""});if(result?.ok){$("apiKey").value="";$("apiMessage").textContent="API Key eliminada de esta instalación.";await analyze(false)}}
$("saveHistory").addEventListener("click",saveHistory); $("clearHistory").addEventListener("click",clearHistory);
document.querySelectorAll(".tab").forEach(b=>b.addEventListener("click",()=>{document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x===b));document.querySelectorAll(".panel").forEach(x=>x.classList.toggle("hidden",x.id!==b.dataset.tab))}));$("refresh").addEventListener("click",()=>analyze(true));$("saveApiKey").addEventListener("click",saveApiKey);$("removeApiKey").addEventListener("click",removeApiKey);$("exportJson").addEventListener("click",()=>lastReport&&download(JSON.stringify(lastReport,null,2),"application/json",`websec-${lastReport.hostname}.json`));$("exportHtml").addEventListener("click",()=>lastReport&&download(buildHtmlReport(lastReport),"text/html;charset=utf-8",`websec-${lastReport.hostname}.html`));analyze(false);

